<header class="header" id="header">
        <div class="header_toggle"> <i class='bx bx-menu' id="header-toggle"></i> </div>
   
                          <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Admin</a>
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="#!">Profile</a>
                                        <a class="dropdown-item" href="registrationform.php">Add New Admin</a>
                                        <a class="dropdown-item" href="includes/activities/logout.php">Logout</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="#!">Something else here</a>
                                    </div>
                                </li>
                            </ul>


       
    </header>
    <div class="l-navbar" id="nav-bar">
        <nav class="nav">
        <!-- <i class="fas fa-align-justify"></i> blog hided -->
            <div> <a href="#" class="nav_logo"> <i class="fas fa-heartbeat" style="color: #fff;"></i> <span class="nav_logo-name">BloodMe</span> </a>
                <div class="nav_list"> 
                    <a href="index.php" class="nav_link"> 
                        <i class='bx bx-grid-alt nav_icon'></i> 
                        <span class="nav_name">Dashboard</span> </a> 
                        <a href="users.php" class="nav_link"> 
                            <i class='bx bx-user nav_icon'></i> 
                            <span class="nav_name">Users</span> </a>
                             <a href="blogs.php" class="nav_link"> 
                                 <i class='bx bx-message-square-detail nav_icon'></i> 
                                 <span class="nav_name">Blogs</span> </a> 
                                 <a href="categories.php" class="nav_link"> 
                                     <i class='bx bx-bookmark nav_icon'></i> 
                                     <span class="nav_name">Categories</span> </a>
                                      <a href="#" class="nav_link"> 
                                          <i class='bx bx-folder nav_icon'></i> 
                                          <span class="nav_name">Files</span> </a> 
                                          <a href="#" class="nav_link"> <i class='bx bx-bar-chart-alt-2 nav_icon'></i> <span class="nav_name">Stats</span> </a> </div>
            </div> <a href="#" class="nav_link"> <i class='bx bx-log-out nav_icon'></i> <span class="nav_name">SignOut</span> </a>
        </nav>
    </div>